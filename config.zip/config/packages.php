<?php //-->
return array (
  'asset' => 
  array (
    'title' => 'Asset Package',
    'installed' => '0.1.0',
    'category' => 'Core',
    'description' => 'Allows assets to be referred though located behind the DMZ.',
    'requires' => '',
    'author' => 'Openovate Labs',
    'website' => 'http://www.openovate.com',
    'demo' => 'http://www.openovate.com',
    'docs' => 'http://www.openovate.com',
  ),
);