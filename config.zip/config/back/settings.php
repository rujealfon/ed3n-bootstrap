<?php //-->
return array(
	'url_root'			=> '',
	'cdn_root'			=> '',
	'i18n'				=> 'en_US',
	'eden_debug' 		=> true,
	'debug_mode' 		=> E_ALL,
	'server_timezone' 	=> 'Asia/Manila',
	'default_page' 		=> 'index');