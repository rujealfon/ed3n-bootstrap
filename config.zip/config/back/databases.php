<?php //-->
return array (
	'default' => array(
		'host' 	=> '127.0.0.1',
		'name' 	=> 'app',
		'user' 	=> 'root',
		'pass' 	=> '',
		'type' 	=> 'mysql',
		'default' => true));